package com.dune.social

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF7657F6)
private val Ink = Color(0xFF171522)
private val Muted = Color(0xFF777487)
private val Surface = Color(0xFFF7F6FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DuneApp() }
    }
}

@Composable
fun DuneApp() {
    var tab by remember { mutableStateOf("Home") }
    MaterialTheme {
        Scaffold(
            backgroundColor = Color.White,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("DUNE", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = 2.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        Icon(Icons.Default.FavoriteBorder, "Likes", tint = Ink)
                        Icon(Icons.Default.Send, "Messages", tint = Ink, modifier = Modifier.clickable { tab = "Chat" })
                    }
                }
            },
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().background(Color.White).padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    NavItem("Home", Icons.Default.Home, tab) { tab = it }
                    NavItem("Explore", Icons.Default.Search, tab) { tab = it }
                    NavItem("Reels", Icons.Default.PlayCircle, tab) { tab = it }
                    NavItem("Chat", Icons.Default.ChatBubbleOutline, tab) { tab = it }
                    NavItem("Profile", Icons.Default.Person, tab) { tab = it }
                }
            }
        ) { padding ->
            when (tab) {
                "Home" -> HomeScreen(Modifier.padding(padding))
                "Explore" -> SimpleScreen("Explore", "Discover people, photos and interests.")
                "Reels" -> SimpleScreen("Reels", "Short videos will appear here.")
                "Chat" -> ChatScreen()
                "Profile" -> SimpleScreen("Your profile", "Your posts, followers and profile settings.")
            }
        }
    }
}

@Composable
fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: String, onSelect: (String) -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onSelect(label) }.padding(horizontal = 5.dp)
    ) {
        Icon(icon, label, tint = if (selected == label) Purple else Muted)
        Text(label, fontSize = 10.sp, color = if (selected == label) Purple else Muted)
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().background(Color.White)) {
        item {
            Text("Stories", fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 10.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                listOf("Your story", "Aarav", "Priya", "Kabir", "Meera").forEachIndexed { i, name ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(58.dp).background(if (i == 0) Surface else Purple.copy(alpha = .14f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(if (i == 0) "+" else name.take(1), color = Purple, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(name, fontSize = 11.sp, color = Ink)
                    }
                }
            }
            Divider(Modifier.padding(top = 14.dp), color = Surface)
        }
        items(listOf("Aarav Mehta", "Priya Sharma", "Kabir Singh")) { name ->
            PostCard(name)
        }
    }
}

@Composable
fun PostCard(name: String) {
    var liked by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).background(Purple.copy(alpha = .15f), CircleShape), contentAlignment = Alignment.Center) {
                Text(name.take(1), color = Purple, fontWeight = FontWeight.Bold)
            }
            Text(name, Modifier.weight(1f).padding(start = 10.dp), fontWeight = FontWeight.SemiBold, color = Ink)
            Icon(Icons.Default.MoreVert, "More", tint = Muted)
        }
        Box(
            Modifier.fillMaxWidth().height(230.dp).padding(horizontal = 12.dp)
                .background(
                    brush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFDDD6FE), Color(0xFFFCE7F3), Color(0xFFE0F2FE))),
                    shape = RoundedCornerShape(14.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text("DUNE MOMENTS", color = Ink.copy(alpha = .55f), fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Like", tint = if (liked) Color.Red else Ink, modifier = Modifier.clickable { liked = !liked })
            Spacer(Modifier.width(16.dp))
            Icon(Icons.Default.ChatBubbleOutline, "Comment", tint = Ink)
            Spacer(Modifier.width(16.dp))
            Icon(Icons.Default.Send, "Share", tint = Ink)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.BookmarkBorder, "Save", tint = Ink)
        }
        Text(if (liked) "You and 128 others liked this" else "128 likes", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Ink)
        Text("$name  Living the moment ✨", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), fontSize = 13.sp, color = Ink)
    }
}

@Composable
fun ChatScreen() {
    var message by remember { mutableStateOf("") }
    val people = listOf("Aarav Mehta", "Priya Sharma", "Kabir Singh", "Meera Verma")
    Column(Modifier.fillMaxSize().background(Color.White)) {
        Text("Messages", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(18.dp))
        people.forEach { person ->
            Row(
                Modifier.fillMaxWidth().clickable { }.padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(46.dp).background(Purple.copy(alpha = .14f), CircleShape), contentAlignment = Alignment.Center) {
                    Text(person.take(1), color = Purple, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.padding(start = 12.dp).weight(1f)) {
                    Text(person, fontWeight = FontWeight.SemiBold, color = Ink)
                    Text("Tap to open conversation", color = Muted, fontSize = 12.sp)
                }
                Text("Now", color = Muted, fontSize = 11.sp)
            }
            Divider(color = Surface)
        }
        Spacer(Modifier.weight(1f))
        Text("Demo inbox · live messaging is not connected yet", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(16.dp))
    }
}

@Composable
fun SimpleScreen(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().background(Color.White).padding(22.dp)) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(subtitle, color = Muted, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().height(180.dp).background(Surface, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Text("Coming soon to DUNE", color = Purple, fontWeight = FontWeight.SemiBold)
        }
    }
}
